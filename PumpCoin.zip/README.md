# [PumpCoin - The World's First Official Pump Coin](http://pumpi.co)

[PumpCoin](http://pumpi.co/) is an Initial Coin Offering meant to make everyone BAG holders. Join the wave and hodl your BAG today.

## About

Be an early adopter in the Blockchain. Purchase PumpCoin (symbol: BAG) through the state-of-the-art ERC20 standard Smart Contract using your ETH. We try to use as many buzz-words as we possibly can to make us sound as legitimate as possible. Here are some other buzz-words: Crowdsourced, Consensus, Byzantine Fault Tolerant, Market Makers. Impressive right?

Read more in our whitepaper: https://docs.google.com/document/d/1WN_rseS8zD7FAqnZ37J0-w1dWronTvz2DHfMzINXqyA/edit

It's completely legit!

## Copyright and License

Copyright 2018 PumpCoin Code released under the [MIT] license.
