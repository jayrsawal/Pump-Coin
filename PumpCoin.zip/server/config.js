var apiKey = "TBMP972T2C6J3JT55A36786U79KUQQQ813";
var smartAddr = "0xDF6cdF88A9c16c02c80B6b735EDa68207c833e55";

module.exports = {
    api_key : apiKey
    , smart_addr : smartAddr
};